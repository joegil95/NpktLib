/*
header tcpip.h
*/

// constantes generales

#define ETHERNET		0x0001	// valeur normalisee pour ethernet support */

#define TYPE_ARP		0x0806
#define TYPE_IP			0x0800
#define TYPE_IP_v6			0x86DD

// Constantes ARP

#define REQUEST_ARP	0x0001	// demande ARP
#define ANSWER_ARP	0x0002	// reponse ARP

// constantes IP

#define PROT_ICMP	0x01	// protocole icmp
#define PROT_TCP	0x06	// protocole tcp
#define PROT_UDP	0x11	// protocole udp

#define PROT_ICMP_v6	0x3A

// Constantes ICMP

#define	ANSWER_ICMP		0x00	// reponse echo
#define	REQUEST_ICMP	0x08	// demande echo

#define	REQUEST_ICMP_v6	0x80	// demande echo
#define ANSWER_ICMP_v6	0x81	// reponse echo

// structures

struct ADR_eth			/* adresse ethernet sur 6 octets */
	{
	__pragma(pack(push, 1)) 
	unsigned char oct[6];
	__pragma(pack(pop))
	};

struct ADR_ip			/* adresse ip sur 4 octets */
	{
	__pragma(pack(push, 1)) 
	unsigned char dec[4];
	__pragma(pack(pop))
	};
	
struct ADR_ip_v6			/* adresse ip sur 16 octets */
	{
	__pragma(pack(push, 1)) 
	unsigned short hex[8];
	__pragma(pack(pop))
	};

struct DTG_arp		// datagramme ARP
	{
	__pragma(pack(push, 1))			// packed struct (alignement)
	unsigned short hard;	
	unsigned short prot;
	unsigned char lgr_hard;
	unsigned char lgr_prot;
	unsigned short op;
	struct ADR_eth srce_eth;
	struct ADR_ip srce_ip;
	struct ADR_eth dest_eth;
	struct ADR_ip dest_ip;
	__pragma(pack(pop))
	};

struct DTG_icmp		// message ICMP de base
	{
	__pragma(pack(push, 1))			// packed struct (alignement)
	unsigned char type;
	unsigned char code;
	unsigned short check;
	unsigned short ident;
	unsigned short seq;			
	unsigned char data[1500];
	__pragma(pack(pop))
	};

struct DTG_ip		// datagramme IP de base
	{
	__pragma(pack(push, 1)) 
	unsigned char vers_lgr;
	unsigned char prior;
	unsigned short lgr_tot;	
	unsigned short rand_id;
	unsigned short frag;
	unsigned char life;
	unsigned char prot;
	unsigned short check;
	struct ADR_ip srce_ip;
	struct ADR_ip dest_ip;
	struct DTG_icmp data;		// cas particulier
	__pragma(pack(pop))
	};

union PACK		// datagramme ARP ou IP au choix
	{
	__pragma(pack(push, 1)) 
	struct DTG_arp dtg_arp;
	struct DTG_ip dtg_ip;
	__pragma(pack(pop))
	};

struct TRAME_eth	// trame Ethernet
  	{
	__pragma(pack(push, 1)) 
  	struct ADR_eth dest;
  	struct ADR_eth srce;
  	unsigned short type;

	union PACK data;
	__pragma(pack(pop))
  	};


struct DTG_icmp_v6			// message ICMP v6 de base<=> ICMP v4
	{
	__pragma(pack(push, 1))			// packed struct (alignement)
	unsigned char type;
	unsigned char code;
	unsigned short check;
	unsigned short ident;
	unsigned short seq;			
	unsigned char data[1500];
	__pragma(pack(pop))
	};

struct PSEUDO_icmp_v6		// pseudo entete ICMP v6 pour calcul du checksum ICMP v6
	{
	__pragma(pack(push, 1)) 
	struct ADR_ip_v6 srce_ip;
	struct ADR_ip_v6 dest_ip;
	unsigned short lgr_high;
	unsigned short lgr_low;
	unsigned char dummy1;
	unsigned short dummy2;
	unsigned char prot;
	__pragma(pack(pop))
	};

struct DTG_ip_v6		// datagramme IP v6 de base
	{
	__pragma(pack(push, 1)) 
	unsigned char vers_prior;
	unsigned char flow1;
	unsigned short flow2;
	unsigned short lgr_util;	
	unsigned char next;
	unsigned char life;
	struct ADR_ip_v6 srce_ip;
	struct ADR_ip_v6 dest_ip;
	struct DTG_icmp_v6 data;		// cas particulier
	__pragma(pack(pop))
	};

struct TRAME_eth_v6		// trame Ethernet pour IP v6
  	{
	__pragma(pack(push, 1)) 
  	struct ADR_eth dest;
  	struct ADR_eth srce;
  	unsigned short type;

	struct DTG_ip_v6 dtg_v6;
	__pragma(pack(pop))
  	};


