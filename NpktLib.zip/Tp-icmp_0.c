/*
 * Test NpCap afin de realiser une librairie de type Packet Driver
 * @(#) JG 2020
 * A compiler sous VC++
 *
 */

// NB: il n'est pas n�cessaire de d�sactiver Unicode


#include "pcap.h"
#include "tcpip.h"

#include "NpktLib.h"


// structures fournies

struct ADR_eth BROADCAST= {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
struct ADR_eth NUL_ETH= {0, 0, 0, 0, 0, 0};
struct ADR_ip NUL_IP= {0, 0, 0, 0};


struct ADR_eth local_eth, host_eth;
struct ADR_ip local_ip, host_ip;


// fonctions fournies

// Saisie d'une adresse ip
void get_ip(struct ADR_ip * ip_ptr)	
	{
	unsigned numa, numb, numc, numd;

	scanf("%u.%u.%u.%u", &numa, &numb, &numc, &numd);
	sprintf(ip_ptr->dec, "%c%c%c%c", numa, numb, numc, numd);
	}

// Affichage d'une adresse ethernet
void put_eth(struct ADR_eth adresse)	
	{
	int i;
	unsigned char c;

	for (i= 0 ; i < sizeof(struct ADR_eth) ; i++)
		{
		c= *((char *) &adresse+i);
		printf("%2.2X ", c);
		}
	printf("\n\n");
	}

// Affichage d'une adresse ip
void put_ip(struct ADR_ip adresse)	
	{
	int i;
	unsigned char c;

	for (i= 0 ; i < sizeof(struct ADR_ip) ; i++)
		{
		c= *((char *) &adresse+i);
		printf("%d.", c);
		}
	printf("\n\n");
	}

// Comparaison de deux adresses ethernet
int comp_eth(struct ADR_eth adresse1, struct ADR_eth adresse2)
	{
	int i;

	for (i= 0 ; i < sizeof(struct ADR_eth) ; i++)
		{
		if (adresse1.oct[i] != adresse2.oct[i])
			return FALSE;
		}

	return TRUE;
	}

// Comparaison de deux adresses IP
int comp_ip(struct ADR_ip adresse1, struct ADR_ip adresse2)
	{
	int i;

	for (i= 0 ; i < sizeof(struct ADR_ip) ; i++)
		{
		if (adresse1.dec[i] != adresse2.dec[i])
			return FALSE;
		}

	return TRUE;
	}

// Affichage brut d'une trame
void show_trame(char * trm_ptr, int siz)		
	{
	int i;
	unsigned char c;
	unsigned char * c_ptr;

	for (i= 0 ; i < siz ; i++)
		{
		c_ptr= (unsigned char *) trm_ptr;
		c= *(c_ptr+i);
		printf("%2.2X ", c);
		}

	printf("\n\n");
	}

// Conversion ordre normalise reseau
u_short xchg(u_short x)
	{
	u_short y= x >> 8;
	y+= x << 8;

	return y;
	}



int main()
	{
	Npkt_Handle Npkt_Hd= NULL;




	// Ouverture du "packet Driver"




	// Recuperation et affichage des adresses locales




	// Preparation requete ARP




	// Emission requete ARP




	// Attente reponse ARP




	// Preparation requete PING




	// Attente reponse PING




	// Fermeture du "Packet Driver"



	getch();
	return 0;
	}
